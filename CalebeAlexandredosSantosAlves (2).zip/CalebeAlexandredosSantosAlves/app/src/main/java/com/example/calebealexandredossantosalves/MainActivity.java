package com.example.calebealexandredossantosalves;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private String name = "Calebe";
    private String surname = "Alves";
    private String matricula = "200028140 ";
    private String allCharacters = name + surname + matricula;
    private Set<Character> uniqueCharacters = new LinkedHashSet<>();
    private TextView Nometv, Sobrenometv, Matriculatv, Provatv, Mensagemtv;
    private GridLayout gridLayout;
    private Button btnEmbaralhar, btnReset;

    private int revealedCharacters = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        for (char c : allCharacters.toCharArray()) {
            uniqueCharacters.add(c);
        }

        Provatv = findViewById(R.id.textView);
        Nometv = findViewById(R.id.textView9);
        Sobrenometv = findViewById(R.id.textView10);
        Matriculatv = findViewById(R.id.textView11);
        Mensagemtv = findViewById(R.id.tv_mensagem);
        gridLayout = findViewById(R.id.gridLayout);
        btnEmbaralhar = findViewById(R.id.button);
        btnReset = findViewById(R.id.button2);

        Provatv.setText("Prova 1: Matr: " + matricula);
        resetGame();

        createButtons();

        btnEmbaralhar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shuffleButtons();
            }
        });

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetGame();
            }
        });
    }

    private void createButtons() {
        LayoutInflater inflater = LayoutInflater.from(this);
        gridLayout.removeAllViews();

        for (char c : uniqueCharacters) {
            Button button = (Button) inflater.inflate(R.layout.btn_layout, gridLayout, false);
            button.setText(String.valueOf(c));
            button.setBackgroundColor(Color.WHITE);
            button.setTextColor(Color.BLACK);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    revealCharacter(c);
                    button.setBackgroundColor(ContextCompat.getColor(MainActivity.this, android.R.color.holo_orange_light));
                    button.setTextColor(Color.WHITE);
                    button.setEnabled(false);
                    revealedCharacters++;
                    checkCompletion();
                }
            });
            gridLayout.addView(button);
        }
    }

    private void checkCompletion() {
        if (revealedCharacters == uniqueCharacters.size()) {
            Mensagemtv.setText("PARABÉNS! VOCÊ COMPLETOU! ");
            Mensagemtv.setVisibility(View.VISIBLE);
        }
    }


    private void shuffleButtons() {
        List<View> children = new ArrayList<>();
        for (int i = 0; i < gridLayout.getChildCount(); i++) {
            children.add(gridLayout.getChildAt(i));
        }
        Collections.shuffle(children);
        gridLayout.removeAllViews();
        for (View child : children) {
            gridLayout.addView(child);
        }
    }

    private void resetGame() {
        Nometv.setText(maskString(name));
        Sobrenometv.setText(maskString(surname));
        Matriculatv.setText(maskString(matricula));
        Mensagemtv.setText("");
        Mensagemtv.setVisibility(View.GONE);
        revealedCharacters = 0;
        createButtons();
    }

    private String maskString(String str) {
        return str.replaceAll(".", "*");
    }

    private void revealCharacter(char ch) {
        Nometv.setText(revealCharacterInString(Nometv.getText().toString(), name, ch));
        Sobrenometv.setText(revealCharacterInString(Sobrenometv.getText().toString(), surname, ch));
        Matriculatv.setText(revealCharacterInString(Matriculatv.getText().toString(), matricula, ch));
    }

    private String revealCharacterInString(String maskedString, String originalString, char ch) {
        StringBuilder revealedString = new StringBuilder(maskedString);
        for (int i = 0; i < originalString.length(); i++) {
            if (originalString.charAt(i) == ch) {
                revealedString.setCharAt(i, ch);
            }
        }
        return revealedString.toString();
    }

    private int countOccurrences(String str, char ch) {
        int count = 0;
        for (char c : str.toCharArray()) {
            if (c == ch) {
                count++;
            }
        }
        return count;
    }
}